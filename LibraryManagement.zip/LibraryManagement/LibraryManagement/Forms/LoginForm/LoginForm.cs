﻿using LibraryManagement.Data;
using LibraryManagement.Helpers;
using LibraryManagement.Models;

namespace LibraryManagement.Forms.LoginForm;

public partial class LoginForm : Form
{
    public LoginForm()
    {
        InitializeComponent();
        ApplyWhiteBlackTheme();
        lblForgotPass.LinkClicked += lblForgotPass_LinkClicked;
    }

    private void ApplyWhiteBlackTheme()
    {
        this.BackColor = Color.White;
        this.ForeColor = Color.Black;
        cardPanel.BackColor = Color.White;
        cardPanel.ForeColor = Color.Black;

        foreach (Control ctrl in cardPanel.Controls)
        {
            ctrl.BackColor = Color.White;
            ctrl.ForeColor = Color.Black;
        }
    }

    private void LoginForm_Load(object sender, EventArgs e)
    {
        rdoReader.Checked = true;

        try
        {
            using var context = new LibraryDbContext();

            if (!context.Users.Any(u => u.Username == "admin"))
            {
                context.Users.Add(new Users
                {
                    UserCode = "NV000",
                    Username = "admin",
                    PasswordHash = "123456",
                    FullName = "Quản trị viên",
                    UserType = "Admin",
                    MaxActiveCopies = null,
                    Status = "Active"
                });
                context.SaveChanges();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Lỗi khởi tạo cơ sở dữ liệu: {ex.Message}", "Lỗi",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void rdoReader_CheckedChanged(object sender, EventArgs e)
    {
        if (rdoReader.Checked)
        {
            lblUsernameTitle.Text = "Mã độc giả hoặc email";
            txtUsername.Clear();
            txtPassword.Clear();
        }
    }

    private void rdoLibrarian_CheckedChanged(object sender, EventArgs e)
    {
        if (rdoLibrarian.Checked)
        {
            lblUsernameTitle.Text = "Tên đăng nhập thủ thư";
            txtUsername.Clear();
            txtPassword.Clear();
        }
    }

    private void btnLogin_Click(object sender, EventArgs e)
    {
        string username = txtUsername.Text.Trim();
        string password = txtPassword.Text;

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            using var context = new LibraryDbContext();

            if (rdoLibrarian.Checked)
            {
                var librarian = context.Users.FirstOrDefault(l =>
                    l.Username == username &&
                    l.PasswordHash == password &&
                    (l.UserType == "Librarian" || l.UserType == "Admin"));

                if (librarian != null)
                {
                    if (librarian.Status.Equals("Inactive", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Tài khoản thủ thư đang bị khóa!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }

                    Session.CurrentLibrarianId = librarian.Id;

                    var f = new LibrarianFormMain();
                    f.FormClosed += (_, _) => AfterClose(f.IsLogout);
                    this.Hide();
                    f.Show();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản hoặc mật khẩu thủ thư.", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                var reader = context.Users.FirstOrDefault(r =>
                    (r.UserCode == username || r.Email == username) &&
                    r.PasswordHash == password &&
                    r.UserType == "Reader");

                if (reader != null)
                {
                    if (reader.Status.Equals("Inactive", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Tài khoản của bạn đang bị khóa, vui lòng liên hệ thủ thư!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }

                    Session.CurrentReaderId = reader.Id;

                    var f = new HomePage.HomePage();
                    f.FormClosed += (_, _) => AfterClose(f.IsLogout);
                    this.Hide();
                    f.Show();
                }
                else
                {
                    MessageBox.Show("Sai mã độc giả/email hoặc mật khẩu.", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Lỗi kết nối cơ sở dữ liệu: {ex.Message}", "Lỗi",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnRegister_Click(object sender, EventArgs e)
    {
        if (rdoLibrarian.Checked)
        {
            MessageBox.Show("Thủ thư không được tự đăng ký tài khoản.", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var registerForm = new RegisterForm.RegisterForm();
        if (registerForm.ShowDialog() == DialogResult.OK)
        {
            txtUsername.Text = registerForm.RegisteredEmail;
            txtPassword.Clear();
            txtPassword.Focus();
        }
    }

    private void lblForgotPass_LinkClicked(object? sender, LinkLabelLinkClickedEventArgs e)
    {
        if (rdoLibrarian.Checked)
        {
            MessageBox.Show("Thủ thư vui lòng liên hệ quản trị viên để cấp lại mật khẩu.", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var forgotForm = new ForgotPasswordForm.ForgotPasswordForm();
        forgotForm.ShowDialog();
    }

    private void AfterClose(bool logout)
    {
        if (logout)
        {
            txtPassword.Clear();
            Session.Clear();
            this.Show();
        }
        else
        {
            this.Close();
        }
    }
}